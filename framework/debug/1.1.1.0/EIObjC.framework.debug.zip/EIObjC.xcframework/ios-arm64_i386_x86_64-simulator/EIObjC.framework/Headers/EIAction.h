//
//  EIAction.h
//  Copyright © 2020 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIGeometry.h>

@interface EIAction : NSObject

@property (atomic, copy) NSString* _Nonnull name;
@property (atomic, copy) NSString* _Nonnull title;
@property (atomic, copy) NSString* _Nonnull type;
@property (atomic, copy) NSString* _Nullable viewTarget;
@property (atomic, copy) NSString* _Nullable elementId;
@property (atomic, assign) long elapsedTime;
@property (nonatomic, assign) CGPoint coordinate;
@property (atomic, assign) BOOL isOutbound;

-(nonnull NSString *)description;

@end
