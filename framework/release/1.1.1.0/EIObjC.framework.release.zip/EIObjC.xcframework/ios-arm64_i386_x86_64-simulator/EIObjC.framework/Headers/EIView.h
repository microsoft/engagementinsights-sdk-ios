//
//  EIView.h
//  Copyright © 2020 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EIView : NSObject

@property (atomic, copy) NSString* _Nonnull name;
@property (atomic, copy) NSString* _Nullable title;
@property (atomic, copy) NSString* _Nullable previousViewName;
@property (nonatomic, assign) float height;
@property (nonatomic, assign) float width;
@property (nonatomic, assign) float viewportHeight;
@property (nonatomic, assign) float viewportWidth;

-(nonnull NSString *)description;

@end
