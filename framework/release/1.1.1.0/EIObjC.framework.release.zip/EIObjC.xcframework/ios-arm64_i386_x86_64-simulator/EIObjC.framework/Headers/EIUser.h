//
//  EIUser.h
//  Copyright © 2020 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EIEvent.h"

@interface EIUser : NSObject

@property (atomic, copy) NSString* _Nullable name;
@property (atomic, copy) NSString* _Nullable localId;
@property (atomic, copy) NSString* _Nullable authId;
@property (atomic, copy) NSString* _Nullable authType;
@property (atomic, copy) NSString* _Nullable email;

- (nonnull NSString *)description;
- (void)processEvent:(nonnull EIEvent *)event;

@end
